
  # Healthcare Management Platform Design

  This is a code bundle for Healthcare Management Platform Design. The original project is available at https://www.figma.com/design/jEIoO06NkvdEx47Pyzayq4/Healthcare-Management-Platform-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  